<?php

	session_start();	
	session_destroy();    		
?>
<html>

<head>
<meta>
<link href="../CSS/w3.css" rel="stylesheet">
</head>

<body>

<h1>Sesion cerrada correctamente!</h1>
<a href="../index.php">
<input class="w3-button w3-round w3-orange w3-section" type="button" value="Regresar">
</a>

</body>

</html>
<?php ?>