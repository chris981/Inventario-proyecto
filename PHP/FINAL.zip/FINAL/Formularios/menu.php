        <div class="w3-bar w3-orange">
            <b><a class="w3-bar-item w3-button" href="../Formularios/Main.php">Inicio</a></b>
            <div class="w3-dropdown-hover">
                <button class="w3-button">Mantenimiento</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="mEmpleados.php" class="w3-bar-item w3-button">Empleados</a>
                </div>
            </div>
            <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/mSolicitudPedidos.php">Solicitud de Pedidos </a>
            <a class="w3_bar-item w3-button w3-hide-small" href="../Formularios/mControlRBDFrituras.php">Control RBD Frituras</a>
            <a class="w3_bar-item w3-button w3-hide-small" href="../Formularios/mVentas.php">Ventas</a>
            <a class="w3_bar-item w3-button w3-hide-small" href="../Formularios/mFreidora.php">Freidora</a>
            <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/mSuministros.php">Suministros</a>
            <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/manual.php">Manual</a>
            <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/reporte.php">Reporte Ventas</a>
            <a class="w3_bar-item w3-button w3-hide-small" href="../Funciones/logout.php">Salir</a>
            <a class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" href="javascript:void(0)" onclick="myFunction()">&#9776;</a>
            <div id="demo" class="w3-bar-block w3-orange w3-hide w3-hide-large w3-hide-medium">
                <a class="w3-bar-item w3-button" href="../Formularios/mSolicitudPedidos.php">Control Mensual </a>
                <a class="w3-bar-item w3-button" href="../Formularios/mControlRBDFrituras.php">Control RBD Frituras</a>
                <a class="w3-bar-item w3-button" href="../Formularios/mVentas.php">Ventas</a>
                <a class="w3-bar-item w3-button" href="../Formularios/Freidoras.php">Freidora</a>
                <a class="w3-bar-item w3-button" href="../Formularios/Suministros.php">Suministros</a>
                <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/manual.php">Manual</a>
                <a class="w3-bar-item w3-button w3-hide-small" href="../Formularios/reporte.php">Reporte Ventas</a>
                <a class="w3_bar-item w3-button w3-hide-small" href="../Funciones/logout.php">Salir</a>
            </div>
        </div>