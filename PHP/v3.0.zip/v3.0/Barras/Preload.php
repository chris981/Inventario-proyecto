<div class="preloader flex-column justify-content-center align-items-center">
  <img class="animation__shake" src="../dist/img/logo.png" alt="Pollolandia" height="60" width="60">
</div>